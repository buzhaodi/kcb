<?php
//000000000000s:311:"<title>OneBase 开发架构{$category_name}{$article_title}</title><meta name="keywords" content="OneBase,PHP,{$category_name},{$article_title}"/><meta name="description" content="一款基于ThinkPHP5研发的开源免费基础架构，基于OneBase可以快速的研发各类Web应用。{$article_describe}"/>";
?>
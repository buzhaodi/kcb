INSERT INTO `ob_hook` (`name`, `describe`, `addon_list`, `status`, `update_time`, `create_time`) VALUES ('Icon', '图标选择钩子', 'Icon', '1', '0', '0');

INSERT INTO `ob_addon` (`name`, `title`, `describe`, `config`,  `author`, `version`, `status`, `create_time` , `update_time`)  VALUES ('Icon', '图标选择', '图标选择插件', '', 'Bigotry', '1.0', '1', '0', '0');
DELETE FROM ob_hook WHERE `name` = 'ArticleEditor';

DELETE FROM ob_addon WHERE `name` = 'Editor';
<?php
return array (
  'test' => 'OB',
);
?>
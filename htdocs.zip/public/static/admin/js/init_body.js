
$('.fakeloader').show();

null !== ob.store('sidebar-collapse-tag')               &&  $("body").addClass(ob.store('sidebar-collapse-tag'));

null !== ob.store('control-sidebar-fixed-tag')          &&  $("body").addClass(ob.store('control-sidebar-fixed-tag'));

null !== ob.store('control-sidebar-layout-boxed-tag')   &&  $("body").addClass(ob.store('control-sidebar-layout-boxed-tag'));